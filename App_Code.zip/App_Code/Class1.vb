﻿Imports Microsoft.VisualBasic
Imports System.Drawing.Imaging
Public Class Class1
    Sub Image_Resize(ByVal FilePath As String, ByVal NewFileName As String, ByVal Width As Int32, ByVal Height As Int32)
        If System.IO.File.Exists(FilePath) = True Then
            Dim fullSizeImg As System.Drawing.Image = System.Drawing.Image.FromFile(FilePath)
            Dim dummyCallBack As New System.Drawing.Image.GetThumbnailImageAbort(AddressOf ThumbnailCallback)
            Dim thumb As System.Drawing.Image = fullSizeImg.GetThumbnailImage(Width, Height, dummyCallBack, IntPtr.Zero)
            ' MsgBox(NewFileName)
            thumb.Save(NewFileName, ImageFormat.Jpeg)
            thumb.Dispose()
            fullSizeImg.Dispose()
            fullSizeImg = Nothing
            thumb = Nothing
        End If
    End Sub
    Private Function ThumbnailCallback() As Boolean
        Return False
    End Function

   

End Class
