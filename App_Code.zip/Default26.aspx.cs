﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Default26 : System.Web.UI.Page
{
    SqlDataAdapter adp,adp2;
    DataSet ds = new DataSet();
    DataSet ds2 = new DataSet();
    SqlConnection con = new SqlConnection();
    SqlCommand cmd = new SqlCommand();
    protected void Page_Load(object sender, EventArgs e)
    {
        con.ConnectionString = "Data Source=LAPTOP-7FSEBR6V\\SQLEXPRESS;Initial Catalog=thefashionstore;Integrated Security=True;";
        if (con.State == ConnectionState.Closed)
        {
            con.Open();
        }
        if (Session["ctnm"] == "1")
        {
            Label1.Text = Session["fnt"].ToString();

            string sql1 = "select * from all_recs where email_id='" + Session["fnt"].ToString() + "' order by odr_no desc";

            adp = new SqlDataAdapter(sql1, con);
            adp.Fill(ds, "catnm");

            Repeater1.DataSource = ds.Tables["catnm"];
            Repeater1.DataBind();
        }
        else { Response.Redirect("Default16.aspx"); }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["ctnm"] = "";
        Session["admin"] = "";
        Response.Redirect("Default.aspx");
    }
}
